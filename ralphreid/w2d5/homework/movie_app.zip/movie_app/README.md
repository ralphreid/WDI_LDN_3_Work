Backlog

DONE - Refactor main.rb 

DONE - Create new foriegn key table to relating actors & movies

DONE - Refactor to include models for both actos & movies

DONE - Integrate Movie classes with seperated Handlers for movies & actors where appropriate

Extend solution to include the ability to relate actors to movies when 
creating a new actor or updating an existing actor

Extend solution to include the ability to relate movies to actors when creating a new movie or updating an existing movie

Implement a TOGGLE select opiton and create page to allow either actors or movies to be created

Refactor with combined movie & actors views and handlers



Populate db with italian movies in bulk - learn how to injest a csv flie with postgres

Enhance UI

Implement referential integrity in the actors_movies table