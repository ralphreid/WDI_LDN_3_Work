# Load the rails application
require File.expand_path('../application', __FILE__)

# Initialize the rails application
R20130214Cookbook::Application.initialize!
