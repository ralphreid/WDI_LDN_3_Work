# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MoonsApp::Application.config.secret_token = '3052414055a6b8c862f6971b013e9c27c2fc89d8743de4a982a791a9a15c6f1a7515d9c87057dc911cdbec0627b9d8e6f5456a5b6e0490f9abff2aad94d2f0f4'
