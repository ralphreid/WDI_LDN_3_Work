class Moon < ActiveRecord::Base
  attr_accessible :age, :diameter, :image, :mass, :mother_planet, :name, :orbit
end
